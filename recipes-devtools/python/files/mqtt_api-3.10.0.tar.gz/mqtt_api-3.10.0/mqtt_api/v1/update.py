from dataclasses import dataclass
from typing import List, Optional

from mqtt_api.v1.datatypes import (
    AcRatedLimits,
    ComponentDataType,
    DcRatedLimits,
    EVSEStatusAndLimitsPayload,
    MeterValuesACCurrent,
    MeterValuesACVoltage,
    SignedMeterValues,
)
from mqtt_api.v1.enums import (
    AuthorizationStatus,
    AuthorizationTokenType,
    BootStatus,
    CertificateInstallationState,
    ChargingRateUnit,
    ChargingStatus,
    ConnectorCsSideStatus,
    ConnectorStatus,
    CpStates,
    CsConnectorStatus,
    CsContactorStatus,
    DataLinkAction,
    DisplayMsgTriggerReason,
    FaultNameType,
    FirmwareStatus,
    Iso15118MessageType,
    Iso15118SchemaVersion,
    Iso15118SessionStatus,
    KeystoreCertificateType,
    LogsStatus,
    MessageState,
    OperationalStatus,
    ParkingBayStatus,
    Priority,
    ServiceName,
    ServiceStatus,
    SlacStatus,
    TransactionStatus,
    WebsocketStatus,
)


@dataclass
class AuthorizationPayload:
    evse_id: str
    id_token: Optional[str]
    token_type: AuthorizationTokenType
    status: AuthorizationStatus


@dataclass
class ServiceStatusPayload:
    service: ServiceName
    software_version: str
    api_version: str
    status: ServiceStatus


@dataclass
class DeviceModelUpdatePayload:
    components: List[ComponentDataType]
    firmware_version: Optional[str] = None
    sim_iccid: Optional[str] = None
    sim_imsi: Optional[str] = None

    def __post_init__(self) -> None:
        """After initialization, convert dicts to correct class instances."""
        self.components = [
            ComponentDataType(**c) if isinstance(c, dict) else c
            for c in self.components
        ]


@dataclass
class WebsocketStatusPayload:
    status: WebsocketStatus
    csms_url: Optional[str] = None
    identity: Optional[str] = None
    security_profile: Optional[int] = None


@dataclass
class Iso15118StateInfoPayload:
    evse_id: str
    session_status: Iso15118SessionStatus
    info: Optional[dict] = None


@dataclass
class Iso15118MessagePayload:
    evse_id: str
    exi_payload: str
    message_type: Optional[Iso15118MessageType] = None
    message_name: Optional[str] = None
    json_payload: Optional[dict] = None
    iso15118_schema_version: Optional[Iso15118SchemaVersion] = None


@dataclass
class ChangeAvailabilityPayload:
    operational_status: OperationalStatus
    evse_id: Optional[str] = None
    connector_id: Optional[int] = None


@dataclass
class ClockSyncPayload:
    current_time: str


@dataclass
class CsContactorStatusPayload:
    evse_id: str
    status: CsContactorStatus
    info: Optional[str] = None


@dataclass
class BootStatusPayload:
    status: BootStatus


@dataclass
class HlcChargingPayload:
    evse_id: str
    status: bool


@dataclass
class SlacStatusPayload:
    evse_id: str
    run_id: str
    status: SlacStatus


@dataclass
class ParkingBayPayload:
    evse_id: str
    status: ParkingBayStatus


@dataclass
class CableInfoPayload:
    evse_id: str
    connection_status: Optional[ConnectorCsSideStatus] = None
    rated_cable_current: Optional[int] = None
    lock: Optional[CsConnectorStatus] = None


@dataclass
class ConnectorAndChargingPayload:
    evse_id: str
    connector_id: int
    connector_status: Optional[ConnectorStatus] = None
    charging_status: Optional[ChargingStatus] = None


@dataclass
class CpStatusPayload:
    evse_id: str
    connector_id: int
    state: CpStates
    max_voltage: Optional[float] = None
    min_voltage: Optional[float] = None
    duty_cycle: Optional[int] = None


@dataclass
class EvRatedLimitsPayload:
    evse_id: str
    departure_time: Optional[str] = None
    ac_rated_limits: Optional[AcRatedLimits] = None
    dc_rated_limits: Optional[DcRatedLimits] = None


@dataclass
class CsStatusAndLimitsPayload:
    evses: List[EVSEStatusAndLimitsPayload]

    def __post_init__(self) -> None:
        """After initialization, convert dicts to correct class instances."""
        self.evses = [
            EVSEStatusAndLimitsPayload(**e) if isinstance(e, dict) else e
            for e in self.evses
        ]


@dataclass
class HardwareFaultPayload:
    evse_id: str
    component_name: str
    fault_name: FaultNameType


@dataclass
class NotifyEventPayload:
    event_id: int
    timestamp: str
    tech_code: Optional[str] = None
    tech_info: Optional[str] = None
    transaction_id: Optional[str] = None
    evse_id: Optional[str] = None


@dataclass
class MeterValuesPayload:
    timestamp: str
    voltage: MeterValuesACVoltage
    current: MeterValuesACCurrent
    power_factor: float
    frequency: float
    total_active_energy_imported: float
    total_reactive_energy_imported: float
    evse_id: Optional[str] = None
    total_reactive_energy_exported: Optional[float] = None
    total_active_energy_exported: Optional[float] = None
    dc_current: Optional[float] = None
    dc_voltage: Optional[float] = None
    max_current_offered: Optional[float] = None
    max_power_offered: Optional[float] = None
    power_active_import: Optional[float] = None
    soc: Optional[float] = None
    departure_time: Optional[str] = None
    min_charge_power: Optional[float] = None
    min_charge_power_l2: Optional[float] = None
    min_charge_power_l3: Optional[float] = None
    max_charge_power: Optional[float] = None
    max_charge_power_l2: Optional[float] = None
    max_charge_power_l3: Optional[float] = None
    min_discharge_power: Optional[float] = None
    min_discharge_power_l2: Optional[float] = None
    min_discharge_power_l3: Optional[float] = None
    max_discharge_power: Optional[float] = None
    max_discharge_power_l2: Optional[float] = None
    max_discharge_power_l3: Optional[float] = None
    min_charge_current: Optional[float] = None
    max_charge_current: Optional[float] = None
    min_discharge_current: Optional[float] = None
    max_discharge_current: Optional[float] = None
    min_voltage: Optional[float] = None
    max_voltage: Optional[float] = None
    ev_target_energy_request: Optional[float] = None
    ev_min_energy_request: Optional[float] = None
    ev_max_energy_request: Optional[float] = None
    ev_min_v2x_energy_request: Optional[float] = None
    ev_max_v2x_energy_request: Optional[float] = None
    target_soc: Optional[float] = None
    signed_meter_values: Optional[list[SignedMeterValues]] = None


@dataclass
class FirmwareStatusPayload:
    request_id: int
    status: FirmwareStatus


@dataclass
class Iso15118ChargeLimit:
    evse_id: str
    limit: float
    unit: ChargingRateUnit


@dataclass
class LogsStatusPayload:
    request_id: int
    status: LogsStatus


@dataclass
class Iso15118ChargingLoopPowerLimitsPayload:
    evse_id: str
    max_charge_active_power: float
    min_charge_active_power: float
    max_discharge_active_power: float
    min_discharge_active_power: float
    max_charge_reactive_power: float
    max_discharge_reactive_power: float


@dataclass
class SlacDataLinkPayload:
    evse_id: str
    action: DataLinkAction


@dataclass
class DisplayAndPersonalMsgPayload:
    display_msg_trigger_reason: DisplayMsgTriggerReason
    content: str
    total_cost: Optional[float] = None
    language: Optional[str] = None
    priority: Optional[Priority] = None
    evse_id: Optional[str] = None
    message_state: Optional[MessageState] = None
    currency: Optional[str] = None
    qr_code_text: Optional[str] = None
    start_date_time: Optional[str] = None
    end_date_time: Optional[str] = None


@dataclass
class DisplayParamsPayload:
    evse_id: str
    present_soc: Optional[int] = None
    charging_complete: Optional[bool] = None
    min_soc: Optional[int] = None
    target_soc: Optional[int] = None
    max_soc: Optional[int] = None
    remaining_time_to_min_soc: Optional[int] = None
    remaining_time_to_target_soc: Optional[int] = None
    remaining_time_to_max_soc: Optional[int] = None
    battery_energy_capacity: Optional[float] = None
    inlet_hot: Optional[bool] = None


@dataclass
class CertificateInstallationStatusPayload:
    certificate_type: KeystoreCertificateType
    status: CertificateInstallationState


@dataclass
class CostUpdatedPayload:
    total_cost: float
    evse_id: str
    currency: str
    custom_data: Optional[dict] = None


@dataclass
class TransactionStatusPayload:
    transaction_id: str
    status: TransactionStatus
    evse_id: Optional[str] = None
    id_token: Optional[str] = None
    token_type: Optional[AuthorizationTokenType] = None
