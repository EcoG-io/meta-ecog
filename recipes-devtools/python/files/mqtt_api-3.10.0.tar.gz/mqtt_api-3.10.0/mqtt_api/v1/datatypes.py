from dataclasses import dataclass
from typing import Optional

from mqtt_api.v1.enums import (
    ChargingProfileKind,
    ChargingProfilePurpose,
    ChargingRateUnit,
    DataType,
    DeviceModelConnectorType,
    DeviceModelMutabilityType,
    EVSEIsolationStatus,
    EVSEStatusCode,
    Measurandtype,
    RecurrencyKind,
)


@dataclass
class ConnectorDataType:
    id: int
    connector_type: DeviceModelConnectorType


@dataclass
class EVSEDataType:
    ocpp_id: int
    iso15118_id: str
    power_kw: float
    supply_phases: int
    connectors: list[ConnectorDataType]

    def __post_init__(self) -> None:
        """After initialization, convert dicts to correct class instances."""
        self.connectors = [
            ConnectorDataType(**c) if isinstance(c, dict) else c
            for c in self.connectors
        ]


@dataclass
class VariableDataType:
    name: str
    value: str
    instance: Optional[str] = None
    unit: Optional[str] = None
    mutability: Optional[DeviceModelMutabilityType] = None
    constant: Optional[bool] = None
    data_type: Optional[DataType] = None
    values_list: Optional[str] = None


@dataclass
class ComponentDataType:
    name: str
    instance: Optional[str] = None
    variables: Optional[list[VariableDataType]] = None
    evse_id: Optional[int] = None
    connector_id: Optional[int] = None

    def __post_init__(self) -> None:
        """After initialization, convert dicts to correct class instances."""
        self.variables = (
            [
                VariableDataType(**c) if isinstance(c, dict) else c
                for c in self.variables
            ]
            if self.variables
            else None
        )


@dataclass
class AcPowerLimit:
    l1: float
    l2: float
    l3: float


@dataclass
class ACBPTStatusAndLimits:
    evse_max_discharge_power: AcPowerLimit
    evse_min_discharge_power: AcPowerLimit

    def __post_init__(self) -> None:
        """After initialization, convert dicts to correct class instances."""
        if isinstance(self.evse_max_discharge_power, dict):
            self.evse_max_discharge_power = AcPowerLimit(
                **self.evse_max_discharge_power,
            )
        if isinstance(self.evse_min_discharge_power, dict):
            self.evse_min_discharge_power = AcPowerLimit(
                **self.evse_min_discharge_power,
            )


@dataclass
class DCBPTStatusAndLimits:
    evse_max_discharge_power: float
    evse_min_discharge_power: float
    evse_max_discharge_current: float
    evse_min_discharge_current: float


@dataclass
class MaxCurrentByPhase:
    l1: float
    l2: float
    l3: float


@dataclass
class ACStatusAndLimits:
    max_current: MaxCurrentByPhase
    nominal_voltage: float
    rcd_error: bool

    def __post_init__(self) -> None:
        """After initialization, convert dicts to correct class instances."""
        if isinstance(self.max_current, dict):
            self.max_current = MaxCurrentByPhase(**self.max_current)


@dataclass
class DCStatusAndLimits:
    present_voltage: float
    present_current: float
    max_current: float
    min_current: float
    max_voltage: float
    min_voltage: float
    max_power: float
    peak_current_ripple: float
    isolation_status: Optional[EVSEIsolationStatus] = None
    energy_to_be_delivered: Optional[float] = None
    current_reg_tolerance: Optional[float] = None
    evse_power_ramp_limit: Optional[float] = None


@dataclass
class EVSEStatusAndLimitsPayload:
    evse_id: str
    status_code: EVSEStatusCode = EVSEStatusCode.EVSE_READY
    ac: Optional[ACStatusAndLimits] = None
    ac_bpt: Optional[ACBPTStatusAndLimits] = None
    dc: Optional[DCStatusAndLimits] = None
    dc_bpt: Optional[DCBPTStatusAndLimits] = None

    def __post_init__(self) -> None:
        """After initialization, convert dicts to correct class instances."""
        if isinstance(self.ac, dict):
            self.ac = ACStatusAndLimits(**self.ac)
        if isinstance(self.ac_bpt, dict):
            self.ac_bpt = ACBPTStatusAndLimits(**self.ac_bpt)
        if isinstance(self.dc, dict):
            self.dc = DCStatusAndLimits(**self.dc)
        if isinstance(self.dc_bpt, dict):
            self.dc_bpt = DCBPTStatusAndLimits(**self.dc_bpt)


@dataclass
class ChargingSchedulePeriod:
    start_period: int
    limit: float
    number_phases: Optional[int] = None
    phase_to_use: Optional[int] = None


@dataclass
class ChargingSchedule:
    id: int
    charging_rate_unit: ChargingRateUnit
    charging_schedule_period: ChargingSchedulePeriod
    start_schedule: Optional[str] = None
    duration: Optional[int] = None
    min_charging_rate: Optional[float] = None


@dataclass
class ChargingProfile:
    id: int
    stack_level: int
    charging_profile_purpose: ChargingProfilePurpose
    charging_profile_kind: ChargingProfileKind
    charging_schedule: ChargingSchedule
    valid_from: Optional[str] = None
    valid_to: Optional[str] = None
    transaction_id: Optional[str] = None
    recurrency_kind: Optional[RecurrencyKind] = None


@dataclass
class StatusInfo:
    reason_code: str
    additional_info: Optional[str] = None


@dataclass
class ACSetpoint:
    charge_active_power: Optional[float] = None
    charge_reactive_power: Optional[float] = None
    charge_current: Optional[float] = None
    discharge_active_power: Optional[float] = None
    discharge_reactive_power: Optional[float] = None
    discharge_current: Optional[float] = None


@dataclass
class DCSetpoint:
    voltage: float
    charge_current: Optional[float] = None
    discharge_current: Optional[float] = None
    charge_power: Optional[float] = None
    discharge_power: Optional[float] = None


@dataclass
class EVLimits:
    maximum_voltage: float
    minimum_voltage: Optional[float] = None


@dataclass
class ClearChargingProfileType:
    evse_id: Optional[str] = None
    charging_profile_purpose: Optional[ChargingProfilePurpose] = None
    stack_level: Optional[int] = None


@dataclass
class MeterValuesACVoltage:
    l1: float
    l2: float
    l3: float


@dataclass
class MeterValuesACCurrent:
    l1: float
    l2: float
    l3: float


@dataclass
class SignedMeterValues:
    measurand: Measurandtype
    signed_meter_data: str
    signing_method: str
    encoding_method: str
    public_key: str


@dataclass
class AcRatedLimits:
    target_energy_request: Optional[float] = None
    max_voltage: Optional[float] = None
    max_current: Optional[float] = None
    min_current: Optional[float] = None
    max_charge_power: Optional[AcPowerLimit] = None
    min_charge_power: Optional[AcPowerLimit] = None
    max_discharge_power: Optional[AcPowerLimit] = None
    min_discharge_power: Optional[AcPowerLimit] = None
    max_v2x_energy_request: Optional[float] = None
    min_v2x_energy_request: Optional[float] = None


@dataclass
class DcRatedLimits:
    target_energy_request: Optional[float] = None
    max_voltage: Optional[float] = None
    max_charge_current: Optional[float] = None
    max_charge_power: Optional[float] = None
    max_energy_request: Optional[float] = None
    full_soc: Optional[int] = None
    bulk_soc: Optional[int] = None
    min_charge_current: Optional[float] = None
    min_charge_power: Optional[float] = None
    min_voltage: Optional[float] = None
    min_energy_request: Optional[float] = None
    target_soc: Optional[int] = None
    max_discharge_power: Optional[float] = None
    min_discharge_power: Optional[float] = None
    max_discharge_current: Optional[float] = None
    min_discharge_current: Optional[float] = None
    max_v2x_energy_request: Optional[float] = None
    min_v2x_energy_request: Optional[float] = None


@dataclass
class ComponentObject:
    name: str
    instance: Optional[str] = None
    evse_id: Optional[str] = None
    connector_id: Optional[int] = None


@dataclass
class VariableObject:
    name: str
    instance: Optional[str] = None
