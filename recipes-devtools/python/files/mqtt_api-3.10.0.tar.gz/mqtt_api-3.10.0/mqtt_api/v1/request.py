from dataclasses import dataclass
from typing import Any, List, Optional

from mqtt_api.v1.datatypes import (
    ACSetpoint,
    ChargingProfile,
    ClearChargingProfileType,
    ComponentObject,
    DCSetpoint,
    EVLimits,
    VariableObject,
)
from mqtt_api.v1.enums import (
    ActivePowerFunction,
    AuthorizationTokenType,
    CableCheckAction,
    CsConnectorAction,
    GridCode,
    HashAlgorithm,
    Iso15118AuthorizationTokenType,
    Iso15118CertificateAction,
    Iso15118SchemaVersion,
    KeystoreCertificateType,
    LogType,
    OcppMessageName,
    OcppVersion,
    OperationalStatus,
    PrivateKeyAlgorithm,
    ReactivePowerFunction,
    RemoteGridCodeOperation,
    SecurityType,
    ServiceName,
    VariableAttribute,
)


@dataclass
class AuthorizationPayload:
    token_type: AuthorizationTokenType
    evse_id: Optional[str] = None
    id_token: Optional[str] = None


@dataclass
class ServiceStatusPayload:
    service: ServiceName


@dataclass
class Iso15118GetEvCertificatePayload:
    action: Iso15118CertificateAction
    iso15118_schema_version: Iso15118SchemaVersion
    exi_request: str


@dataclass
class CpPwmPayload:
    evse_id: str
    hlc: bool = False
    # 1 decimal point; 0A means 100% duty cycle, EVSE not ready/pwm off
    current: Optional[float] = None
    error_state: bool = False  # true; true means 0% duty cycle and 0V (state E)
    fault_state: bool = False  # true;


@dataclass
class CsConnectorPayload:
    evse_id: str
    connector_id: int
    action: CsConnectorAction


@dataclass
class CertificateHashData:
    hash_algorithm: HashAlgorithm
    issuer_name_hash: str
    issuer_key_hash: str
    serial_number: str
    responder_url: str


@dataclass
class EmaidTokenData:
    iso15118_hash_data: Optional[List[CertificateHashData]] = None
    certificate_chain: Optional[str] = None


@dataclass
class Iso15118AuthorizationPayload:
    evse_id: str
    token_type: Iso15118AuthorizationTokenType
    id_token: Optional[str] = None
    token_data: Optional[EmaidTokenData] = None


@dataclass
class CsStatusAndLimitsPayload:
    pass


@dataclass
class DeviceModelPayload:
    pass


@dataclass
class DeviceModelResetPayload:
    pass


@dataclass
class CsContactorStatusPayload:
    evse_id: str


@dataclass
class StopChargingPayload:
    evse_id: str


@dataclass
class ChangeAvailabilityPayload:
    operational_status: OperationalStatus
    evse_id: Optional[str] = None
    connector_id: Optional[int] = None


@dataclass
class CsParametersPayload:
    pass


@dataclass
class ResetPayload:
    evse_id: Optional[str] = None


@dataclass
class UpdateFirmwarePayload:
    request_id: int
    location: str
    retrieve_datetime: str
    install_datetime: Optional[str] = None
    retries: Optional[int] = None
    retry_interval: Optional[int] = None
    signing_certificate: Optional[str] = None
    signature: Optional[str] = None


@dataclass
class UploadLogsPayload:
    request_id: int
    log_type: LogType
    remote_location: str
    retries: Optional[int] = None
    retry_interval: Optional[int] = None
    oldest_timestamp: Optional[str] = None
    latest_timestamp: Optional[str] = None


# ResetOCPPRouterState is only used for integration tests.
# This isn't listed in the book and should be removed
# at some point.
@dataclass
class ResetOCPPRouterStatePayload:
    test_name: Optional[str] = None


@dataclass
class SlacLinkStatusPayload:
    evse_id: str


@dataclass
class SlacNetworkInfo:
    evse_id: str


@dataclass
class SetChargingProfilePayload:
    charging_profile: ChargingProfile
    evse_id: Optional[str]


@dataclass
class SetOcppNetworkConnectionPayload:
    csms_url: str
    security_profile: int
    identity: Optional[str] = None
    basic_auth_password: Optional[str] = None


@dataclass
class RemoteGridCodeOperationPayload:
    evse_id: str
    remote_procedure: RemoteGridCodeOperation
    set_point: Optional[float] = None


@dataclass
class GenerateCsrPayload:
    certificate_type: KeystoreCertificateType
    common_name: str
    organization_name: str
    country_name: str
    algorithm: Optional[PrivateKeyAlgorithm]
    evse_id: Optional[str] = None


@dataclass
class GridCodeSettingsPayload:
    evse_id: str
    gridcode_id: GridCode
    reactive_power_function_enabled: Optional[ReactivePowerFunction]
    active_power_functions_enabled: List[ActivePowerFunction]
    remote_procedures_enabled: List[RemoteGridCodeOperation]


@dataclass
class CableCheckPayload:
    evse_id: str
    cable_check_action: CableCheckAction


@dataclass
class SDPPayload:
    evse_id: str
    security: SecurityType


@dataclass
class DataTransferPayload:
    vendor_id: str
    data: Optional[Any] = None
    message_id: Optional[str] = None


@dataclass
class PowerElectronicsSetpointPayload:
    evse_id: str
    ev_limits: EVLimits
    is_precharge: Optional[bool] = None
    ac: Optional[ACSetpoint] = None
    dc: Optional[DCSetpoint] = None


@dataclass
class PrivateKeyPathPayload:
    certificate_type: KeystoreCertificateType


@dataclass
class ProcessAuthorizedTokenPayload:
    token_type: AuthorizationTokenType
    id_token: Optional[str] = None
    evse_id: Optional[str] = None


@dataclass
class ClearChargingProfilePayload:
    charging_profile_id: Optional[int] = None
    charging_profile_criteria: Optional[ClearChargingProfileType] = None


@dataclass
class MeterValuesPayload:
    timestamp: str
    evse_id: Optional[str] = None


@dataclass
class OcppMessagePayload:
    ocpp_version: OcppVersion
    message_name: OcppMessageName
    payload: dict[str, Any]


@dataclass
class WebsocketStatusPayload:
    pass


@dataclass
class SetVariableValidatePayload:
    component: ComponentObject
    variable: VariableObject
    attribute_value: str
    attribute_type: Optional[VariableAttribute] = VariableAttribute.ACTUAL
