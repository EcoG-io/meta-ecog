# JOSEV's MQTT API

Python Implementation of JOSEV's MQTT API.

_Note_:
The Rust version of the API can be found [here](https://github.com/EcoG-io/josev-api).
Any changes to the API should first be made there, and then ported to this repository.

## Installation

In your project, you can install the mqtt_api package using pip or poetry,
either way the Switch PyPi credentials will be needed and shall be set as
ENV variables:

```shell
$ export PYPI_USER=*****
$ export PYPI_PASS=*****
```

Contact Shalin Nijel <shalin@ecog.io> if you need the credentials.

### Using Poetry

Add this to your pyproject.toml

```toml
[[tool.poetry.source]]
name = "mqtt_api"
url = "https://pypi.ecog.io/simple/"
```

Configure the credentials for the PyPi server:

```shell
$ poetry config http-basic.mqtt_api $PYPI_USER $PYPI_PASS
```

And add the `mqtt_api` as dependency:

```shell
$ poetry add mqtt_api
```

### Using Pip

```shell
pip install --index-url https://$PYPI_USER:$PYPI_PASS@pypi.ecog.io/simple mqtt_api
```

## Local Installation

You can install the package in your local env, by cloning the repo and
following one of the below methods:

### Using Poetry

```shell
$ make install-local
```

### Using pip

```shell
$ pip install .
```

#### Pre-commit hooks

We use various tools, such as `black` and `flake8`, to enforce a consistent code style. `pre-commit` configures Git hooks to run these on every commit.

Activate either virtual environment and create the hooks (they only need to be created once for the repository):

```
source path/to/cs-env/bin/activate
pre-commit install
pre-commit install --hook-type commit-msg
```

## Publishing the package

The package is published automatically, using GitHub Actions, to Switch PyPi
upon a new release that is tagged as `v[Major].[Minor].[Patch]`. Thus, after a
new tag is created based on master branch, e.g. v1.2.0, GitHub takes care of
triggering the workflow to release a new package with that version on PyPi.

Note: The user may notice that pyproject.toml refers to version "0.0.0"; This is
a placeholder version as the one to be published is fetched from GitHub

### Manual Publishing [Not recommended]

If for some reason a manual publishing of the package is required, it is
possible to do it either using Poetry or twine, but we recommend using poetry
either way the credentials for the Switch PyPi server will be prompted.

Before publishing it, consider bumping the package version:

```shell
$ make bump-version
```

Contact Shalin Nijel <shalin@ecog-io> if you need to follow this path.

### Poetry

```shell
make deploy
```

## FAQ

### My request is failing with a TimeoutError. How do I fix this?

Check the following:

- Check that the response is being sent correctly using [MQTTX](https://mqttx.app/) or another equivalent tool.
- The response is sent to the right topic, and `Mqtt` is listening to that topic.
- The instance of `Mqtt` is up and running on a separate coroutine using `start()` before calling `request()`. This is required for `request()` to retrieve the response over mqtt.
