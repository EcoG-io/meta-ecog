import functools
from typing import Any, Callable, Dict, Optional

from mqtt_api.v1.enums import ActionType

routables = []


def on(action: str, action_type: Optional[ActionType] = None) -> Callable:
    """
    Mark function as handler for specific action.

    The handler function will receive keyword arguments derived from the
    payload of the specific action.The optional action type can be provided
    to distinguish update and request/response messages if the same message exists.
    It's recommended you use `**kwargs` in your
    definition to ignore any extra arguments that may be added in the future.
    The handler function should return a relevant payload to be returned to the
    CS.
    It can be used like so:

    @on(MessageName.CS_AUTHORIZATION)
    def on_cs_authorization(self, evse_id: str, **kwargs: Any)
    -> response.CsAuthorizationPayload:
        return response.CsAuthorizationPayload(
            evse_id=evse_id, status=MessageStatus.ACCEPTED
        )
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def inner(*args: Any, **kwargs: Any) -> Callable:
            return func(*args, **kwargs)

        inner._on_action = action  # type: ignore
        inner._action_type = action_type  # type: ignore
        if func.__name__ not in routables:
            routables.append(func.__name__)
        return inner

    return decorator


def after(action: str) -> Callable:
    """Mark function as hook to post-request hook.

    This hook's arguments are the data that is in the payload for the specific
    action.
    It can be used like so:

    @after(MessageName.CS_AUTHORIZATION)
    def after_cs_authorization(self, evse_id: str, **kwargs: Any) -> None:
        pass
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def inner(*args: Any, **kwargs: Any) -> Callable:
            return func(*args, **kwargs)

        inner._after_action = action  # type: ignore
        if func.__name__ not in routables:
            routables.append(func.__name__)
        return inner

    return decorator


def create_route_map(obj: Any) -> Dict:
    """Create a map of all routes from the decorated functions."""
    routes: Dict[Any, Any] = {}
    for attr_name in routables:
        for option in ["_on_action", "_after_action"]:
            try:
                attr = getattr(obj, attr_name)
                action = getattr(attr, option)

                if action not in routes:
                    routes[action] = {}

                routes[action][option] = attr

            except AttributeError:
                continue

    return routes
