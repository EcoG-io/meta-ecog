import decimal
import json
import logging
from dataclasses import asdict, is_dataclass
from typing import Any, Dict, Optional, Tuple, Union

from paho.mqtt.client import MQTTMessage

from mqtt_api.utils import remove_nones
from mqtt_api.v1.enums import ActionType, MessageName


class _DecimalEncoder(json.JSONEncoder):
    """Encode values of type `decimal.Decimal` using 1 decimal point.
    A custom encoder is required because `json.dumps()` cannot encode a value
    of type decimal.Decimal. This raises a TypeError:
        >>> import decimal
        >>> import json
        >>> >>> json.dumps(decimal.Decimal(3))
        Traceback (most recent call last):
          File "<stdin>", line 1, in <module>
          File "/home/developer/.pyenv/versions/3.7.0/lib/python3.7/json/__init__.py", line 231, in dumps  # noqa
            return _default_encoder.encode(obj)
          File "/home/developer/.pyenv/versions/3.7.0/lib/python3.7/json/encoder.py", line 199, in encode
            chunks = self.iterencode(o, _one_shot=True)
          File "/home/developer/.pyenv/versions/3.7.0/lib/python3.7/json/encoder.py", line 257, in iterencode
            return _iterencode(o, 0)
          File "/home/developer/.pyenv/versions/3.7.0/lib/python3.7/json/encoder.py", line 179, in default
            raise TypeError(f'Object of type {o.__class__.__name__} '
        TypeError: Object of type Decimal is not JSON serializable
    This can be prevented by using a custom encoder.
    """

    def default(self, obj: Any) -> Any:
        """Encode decimal types to 1 decimal point."""
        if isinstance(obj, decimal.Decimal):
            return float("%.1f" % obj)
        return json.JSONEncoder.default(self, obj)


class Message:
    message_type: ActionType

    def __init__(self, id: str, name: MessageName, data: Any) -> None:
        """Object initialization.

        Args:
            id: Message id
            name: Message name
            data: Message payload
        """
        self.id = id
        self.name = name
        self.data = data

        if is_dataclass(data) and not isinstance(data, type):
            self.data = asdict(data)

    def to_dict(self) -> Dict:
        """Return a dict representation of the message, without any Nones."""
        return remove_nones(
            {
                "id": self.id,
                "type": self.message_type,
                "name": self.name,
                "data": self.data,
            }
        )

    def to_json(self) -> str:
        """Return a valid JSON representation of the instance."""
        return json.dumps(
            self.to_dict(),
            # By default json.dumps() adds a white space after every separator.
            # By setting the separator manually that can be avoided.
            separators=(",", ":"),
            cls=_DecimalEncoder,
        )

    def to_encoded_json(self) -> bytes:
        """Get the encoded JSON representation of the class."""
        return json.dumps(self.to_dict()).encode()

    def __repr__(self) -> str:
        """Build a repr."""
        return (
            f"<{self.message_type.capitalize()} - id={self.id}, "
            f"name={self.name}, "
            f"data={self.data}>"
        )


class Response(Message):
    message_type = ActionType.RESPONSE


class Request(Message):
    message_type = ActionType.REQUEST

    def create_response(self, data: Any) -> Response:
        """Create Response message in response to the request."""
        return Response(self.id, self.name, data)


class Update(Message):
    message_type = ActionType.UPDATE


def unpack(
    message: MQTTMessage,
) -> Tuple[Optional[Any], Optional[Message]]:
    """Unpacks a message into either a Request, Response or Update."""
    try:
        payload = str(message.payload.decode())
        payload = json.loads(payload)
        topic = message.topic
    except json.decoder.JSONDecodeError as e:
        logging.exception(f"The incoming message is not valid JSON: {e}")

    if not isinstance(payload, dict):
        logging.error(
            "OCPP message hasn't the correct format. It "
            f"should be a dict, but got {type(payload)} instead"
        )
        return None, None

    for cls in [Request, Response, Update]:
        try:
            if payload["type"] == cls.message_type:
                payload.pop("type")
                return topic, cls(**payload)
        except IndexError:
            logging.exception("Message doesn't contain MessageType")

    return None, None


def pack(msg: Union[Request, Response, Update]) -> str:
    """
    Packs the JSON representation of a Request, Response or Update.

    It just calls the 'to_json()' method of the message. But it is here mainly
    to complement the 'unpack' function of this module.
    """
    return msg.to_json()
