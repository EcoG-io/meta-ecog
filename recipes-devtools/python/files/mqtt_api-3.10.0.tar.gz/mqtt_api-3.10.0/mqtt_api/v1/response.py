from dataclasses import dataclass
from typing import Any, List, Optional

from mqtt_api.v1.datatypes import (
    ComponentDataType,
    EVSEDataType,
    EVSEStatusAndLimitsPayload,
    MeterValuesACCurrent,
    MeterValuesACVoltage,
    SignedMeterValues,
    StatusInfo,
)
from mqtt_api.v1.enums import (
    AccessNetwork,
    AuthorizationStatus,
    AuthorizationTokenType,
    AuthorizeCertificateStatus,
    AuthorizedTokenStatus,
    BPTChannel,
    CableCheckStatus,
    ClearChargingProfileStatus,
    ControlMode,
    CpPwmCommandStatus,
    CsConnectorStatus,
    CsContactorStatus,
    DataTransferStatus,
    EnergyTransferModeEnum,
    GeneratorMode,
    GridCodeIslandingDetectionMode,
    GridCodeSetttingStatus,
    Iso15118AuthorizationStatus,
    Iso15118CertificateStatus,
    IsolationLevel,
    LinkStatus,
    MessageStatus,
    OcppMessageType,
    OcppVersion,
    PrivateKeyPathStatus,
    RemoteGridCodeStatus,
    SecurityType,
    ServiceName,
    ServiceStatus,
    SetPointRequestStatus,
    StationRole,
    UpdateFirmwareStatus,
    UploadLogsStatus,
    WebsocketStatus,
)


@dataclass
class AuthorizationPayload:
    status: AuthorizationStatus
    evse_id: Optional[str] = None
    group_id_token: Optional[str] = None
    group_id_token_type: Optional[AuthorizationTokenType] = None
    cache_expiry_date_time: Optional[str] = None


@dataclass
class ServiceStatusPayload:
    service: ServiceName
    software_version: str
    api_version: str
    status: ServiceStatus


@dataclass
class SetOcppNetworkConnectionPayload:
    status: MessageStatus
    reason: Optional[str] = None


@dataclass
class Iso15118GetEvCertificatePayload:
    status: Iso15118CertificateStatus
    exi_response: str


@dataclass
class CpPwmPayload:
    evse_id: str
    status: CpPwmCommandStatus
    info: Optional[str] = None


@dataclass
class CsConnectorPayload:
    evse_id: str
    connector_id: int
    status: CsConnectorStatus
    info: Optional[str] = None


@dataclass
class CsDCConnectorService:
    connector_type: EnergyTransferModeEnum
    control_mode: Optional[ControlMode] = None


@dataclass
class CsDCBptConnectorService:
    connector_type: EnergyTransferModeEnum
    control_mode: Optional[ControlMode] = None
    bpt_channel: Optional[BPTChannel] = None
    generator_mode: Optional[GeneratorMode] = None
    grid_island_detection_mode: Optional[GridCodeIslandingDetectionMode] = None


@dataclass
class CsACConnectorService:
    connector_type: EnergyTransferModeEnum
    nominal_voltage: int
    control_mode: Optional[ControlMode] = None


@dataclass
class CsACBptConnectorService:
    connector_type: EnergyTransferModeEnum
    nominal_voltage: int
    control_mode: Optional[ControlMode] = None
    bpt_channel: Optional[BPTChannel] = None
    generator_mode: Optional[GeneratorMode] = None
    grid_island_detection_mode: Optional[GridCodeIslandingDetectionMode] = None


@dataclass
class CsConnectorServices:
    dc: Optional[CsDCConnectorService] = None
    dc_bpt: Optional[CsDCBptConnectorService] = None
    ac: Optional[CsACConnectorService] = None
    ac_bpt: Optional[CsACBptConnectorService] = None

    def __post_init__(self) -> None:
        """After initialization, convert dicts to correct class instances."""
        if isinstance(self.dc, dict):
            self.dc = CsDCConnectorService(**self.dc)
        if isinstance(self.dc_bpt, dict):
            self.dc_bpt = CsDCBptConnectorService(**self.dc_bpt)
        if isinstance(self.ac, dict):
            self.ac = CsACConnectorService(**self.ac)
        if isinstance(self.ac_bpt, dict):
            self.ac_bpt = CsACBptConnectorService(**self.ac_bpt)


@dataclass
class CsConnectorParameters:
    id: int
    services: CsConnectorServices

    def __post_init__(self) -> None:
        """After initialization, convert dicts to correct class instances."""
        if isinstance(self.services, dict):
            self.services = CsConnectorServices(**self.services)


@dataclass
class CsEvseParameters:
    evse_id: str
    connectors: List[CsConnectorParameters]
    supports_eim: bool
    network_interface: str

    def __post_init__(self) -> None:
        """After initialization, convert dicts to correct class instances."""
        self.connectors = [
            CsConnectorParameters(**c) if isinstance(c, dict) else c
            for c in self.connectors
        ]


@dataclass
class CsParametersPayload:
    sw_version: str
    hw_version: str
    number_of_evses: int
    parameters: List[CsEvseParameters]

    def __post_init__(self) -> None:
        """After initialization, convert dicts to correct class instances."""
        self.parameters = [
            CsEvseParameters(**p) if isinstance(p, dict) else p for p in self.parameters
        ]


@dataclass
class CsStatusAndLimitsPayload:
    evses: List[EVSEStatusAndLimitsPayload]

    def __post_init__(self) -> None:
        """After initialization, convert dicts to correct class instances."""
        self.evses = [
            EVSEStatusAndLimitsPayload(**e) if isinstance(e, dict) else e
            for e in self.evses
        ]


@dataclass
class Iso15118AuthorizationPayload:
    status: Iso15118AuthorizationStatus
    certificate_status: Optional[AuthorizeCertificateStatus] = None


@dataclass
class CsContactorStatusPayload:
    evse_id: str
    status: CsContactorStatus
    info: Optional[str] = None


@dataclass
class DeviceModelPayload:
    model: str
    vendor: str
    identity: str
    ocpp_csms_url: str
    security_profile: int
    basic_auth_password: str
    serial_number: str
    firmware_version: str
    evses: List[EVSEDataType]
    ocpp_version: Optional[OcppVersion] = None
    default_message_timeout: Optional[int] = None
    sim_iccid: Optional[str] = None
    sim_imsi: Optional[str] = None
    components: Optional[List[ComponentDataType]] = None

    def __post_init__(self) -> None:
        """After initialization, convert dicts to correct class instances."""
        self.components = (
            [
                ComponentDataType(**c) if isinstance(c, dict) else c
                for c in self.components
            ]
            if self.components
            else None
        )
        self.evses = [
            EVSEDataType(**e) if isinstance(e, dict) else e for e in self.evses
        ]


@dataclass
class DeviceModelResetPayload:
    status: MessageStatus
    rejected_reason: Optional[str] = None


@dataclass
class DeviceModelUpdatePayload:
    status: MessageStatus
    rejected_reason: Optional[str] = None


@dataclass
class ResetPayload:
    status: MessageStatus


@dataclass
class StopChargingPayload:
    status: MessageStatus
    evse_id: str


@dataclass
class ChangeAvailabilityPayload:
    status: MessageStatus


@dataclass
class UpdateFirmwarePayload:
    status: UpdateFirmwareStatus


@dataclass
class UploadLogsPayload:
    status: UploadLogsStatus
    filename: Optional[str] = None


# ResetOCPPRouterState is only used for integration tests.
# This isn't listed in the book and should be removed
# at some point.
@dataclass
class ResetOCPPRouterStatePayload:
    pass


@dataclass
class SlacLinkStatusPayload:
    evse_id: str
    status: LinkStatus


@dataclass
class SlacNetworkPayload:
    network_id: str
    short_network_id: str
    terminal_equipment_id: str
    station_role: StationRole
    mac_address: str
    access_network: AccessNetwork
    num_coord_nws: int


@dataclass
class SlacNetworkInfoPayload:
    evse_id: str
    networks: List[SlacNetworkPayload]

    def __post_init__(self) -> None:
        """After initialization, convert dicts to correct class instances."""
        self.networks = [
            SlacNetworkPayload(**e) if isinstance(e, dict) else e for e in self.networks
        ]


@dataclass
class SetChargingProfilePayload:
    status: MessageStatus
    status_info: Optional[StatusInfo] = None


@dataclass
class RemoteGridCodeOperationPayload:
    evse_id: str
    status: RemoteGridCodeStatus


@dataclass
class GenerateCsrPayload:
    status: MessageStatus
    csr: Optional[str]


@dataclass
class GridCodeSettingsPayload:
    evse_id: str
    status: GridCodeSetttingStatus


@dataclass
class CableCheckPayload:
    evse_id: str
    cable_check_status: CableCheckStatus
    isolation_level: Optional[IsolationLevel] = None


@dataclass
class SDPPayload:
    evse_id: str
    ip_address: Optional[str] = None
    port: Optional[int] = None
    security: Optional[SecurityType] = None
    error: Optional[str] = None


@dataclass
class DataTransferPayload:
    status: DataTransferStatus
    data: Optional[Any] = None


@dataclass
class PowerElectronicsSetpointPayload:
    evse_id: str
    status: SetPointRequestStatus


@dataclass
class PrivateKeyPathPayload:
    status: PrivateKeyPathStatus
    private_key_path: Optional[str] = None


@dataclass
class ProcessAuthorizedTokenPayload:
    status: AuthorizedTokenStatus
    evse_id: Optional[str] = None


@dataclass
class ClearChargingProfilePayload:
    status: ClearChargingProfileStatus
    status_info: Optional[StatusInfo] = None


@dataclass
class MeterValuesPayload:
    timestamp: str
    voltage: MeterValuesACVoltage
    current: MeterValuesACCurrent
    power_factor: float
    frequency: float
    total_active_energy_imported: float
    total_reactive_energy_imported: float
    evse_id: Optional[str] = None
    total_reactive_energy_exported: Optional[float] = None
    total_active_energy_exported: Optional[float] = None
    dc_current: Optional[float] = None
    dc_voltage: Optional[float] = None
    soc: Optional[float] = None
    max_current_offered: Optional[float] = None
    max_power_offered: Optional[float] = None
    power_active_import: Optional[float] = None
    departure_time: Optional[str] = None
    min_charge_power: Optional[float] = None
    min_charge_power_l2: Optional[float] = None
    min_charge_power_l3: Optional[float] = None
    max_charge_power: Optional[float] = None
    max_charge_power_l2: Optional[float] = None
    max_charge_power_l3: Optional[float] = None
    min_discharge_power: Optional[float] = None
    min_discharge_power_l2: Optional[float] = None
    min_discharge_power_l3: Optional[float] = None
    max_discharge_power: Optional[float] = None
    max_discharge_power_l2: Optional[float] = None
    max_discharge_power_l3: Optional[float] = None
    min_charge_current: Optional[float] = None
    max_charge_current: Optional[float] = None
    min_discharge_current: Optional[float] = None
    max_discharge_current: Optional[float] = None
    min_voltage: Optional[float] = None
    max_voltage: Optional[float] = None
    ev_target_energy_request: Optional[float] = None
    ev_min_energy_request: Optional[float] = None
    ev_max_energy_request: Optional[float] = None
    ev_min_v2x_energy_request: Optional[float] = None
    ev_max_v2x_energy_request: Optional[float] = None
    target_soc: Optional[float] = None
    signed_meter_values: Optional[list[SignedMeterValues]] = None


@dataclass
class OcppMessagePayload:
    ocpp_version: OcppVersion
    message_type: OcppMessageType
    payload: Optional[dict] = None
    error_code: Optional[str] = None
    error_description: Optional[str] = None
    error_details: Optional[dict] = None


@dataclass
class WebsocketStatusPayload:
    status: WebsocketStatus
    csms_url: Optional[str] = None
    identity: Optional[str] = None
    security_profile: Optional[int] = None


@dataclass
class SetVariableValidatePayload:
    result: MessageStatus
