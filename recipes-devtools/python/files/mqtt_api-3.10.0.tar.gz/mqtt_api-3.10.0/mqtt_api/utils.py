import re
from typing import Dict


def camel_to_snake_case(name: str) -> str:
    """Convert CamelCase to snake_case."""
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    return re.sub("([a-z0-9])([A-Z])(?=\\S)", r"\1_\2", s1).lower()


def remove_nones(dict_to_scan: Dict) -> Dict:
    """Remove keys with a value of None."""
    new_dict = {}
    for k, v in dict_to_scan.items():
        if isinstance(v, dict):
            v = remove_nones(v)
        if isinstance(v, list):
            new_list = [
                remove_nones(item) if isinstance(item, dict) else item for item in v
            ]
            v = new_list
        if v is not None:
            new_dict[k] = v
    return new_dict
