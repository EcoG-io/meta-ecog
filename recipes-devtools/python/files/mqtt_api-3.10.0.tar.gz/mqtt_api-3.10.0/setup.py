# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mqtt_api', 'mqtt_api.v1']

package_data = \
{'': ['*'], 'mqtt_api': ['schemas/*']}

install_requires = \
['asyncio-mqtt>=0.16.1,<0.17.0',
 'docutils>=0.21.2,<0.22.0',
 'jsonschema==4.23.0',
 'paho-mqtt>=1.5.0,<2.0.0']

setup_kwargs = {
    'name': 'mqtt-api',
    'version': '3.10.0',
    'description': "Python Implementation of JOSEV's MQTT API",
    'long_description': '# JOSEV\'s MQTT API\n\nPython Implementation of JOSEV\'s MQTT API.\n\n_Note_:\nThe Rust version of the API can be found [here](https://github.com/EcoG-io/josev-api).\nAny changes to the API should first be made there, and then ported to this repository.\n\n## Installation\n\nIn your project, you can install the mqtt_api package using pip or poetry,\neither way the Switch PyPi credentials will be needed and shall be set as\nENV variables:\n\n```shell\n$ export PYPI_USER=*****\n$ export PYPI_PASS=*****\n```\n\nContact Shalin Nijel <shalin@ecog.io> if you need the credentials.\n\n### Using Poetry\n\nAdd this to your pyproject.toml\n\n```toml\n[[tool.poetry.source]]\nname = "mqtt_api"\nurl = "https://pypi.ecog.io/simple/"\n```\n\nConfigure the credentials for the PyPi server:\n\n```shell\n$ poetry config http-basic.mqtt_api $PYPI_USER $PYPI_PASS\n```\n\nAnd add the `mqtt_api` as dependency:\n\n```shell\n$ poetry add mqtt_api\n```\n\n### Using Pip\n\n```shell\npip install --index-url https://$PYPI_USER:$PYPI_PASS@pypi.ecog.io/simple mqtt_api\n```\n\n## Local Installation\n\nYou can install the package in your local env, by cloning the repo and\nfollowing one of the below methods:\n\n### Using Poetry\n\n```shell\n$ make install-local\n```\n\n### Using pip\n\n```shell\n$ pip install .\n```\n\n#### Pre-commit hooks\n\nWe use various tools, such as `black` and `flake8`, to enforce a consistent code style. `pre-commit` configures Git hooks to run these on every commit.\n\nActivate either virtual environment and create the hooks (they only need to be created once for the repository):\n\n```\nsource path/to/cs-env/bin/activate\npre-commit install\npre-commit install --hook-type commit-msg\n```\n\n## Publishing the package\n\nThe package is published automatically, using GitHub Actions, to Switch PyPi\nupon a new release that is tagged as `v[Major].[Minor].[Patch]`. Thus, after a\nnew tag is created based on master branch, e.g. v1.2.0, GitHub takes care of\ntriggering the workflow to release a new package with that version on PyPi.\n\nNote: The user may notice that pyproject.toml refers to version "0.0.0"; This is\na placeholder version as the one to be published is fetched from GitHub\n\n### Manual Publishing [Not recommended]\n\nIf for some reason a manual publishing of the package is required, it is\npossible to do it either using Poetry or twine, but we recommend using poetry\neither way the credentials for the Switch PyPi server will be prompted.\n\nBefore publishing it, consider bumping the package version:\n\n```shell\n$ make bump-version\n```\n\nContact Shalin Nijel <shalin@ecog-io> if you need to follow this path.\n\n### Poetry\n\n```shell\nmake deploy\n```\n\n## FAQ\n\n### My request is failing with a TimeoutError. How do I fix this?\n\nCheck the following:\n\n- Check that the response is being sent correctly using [MQTTX](https://mqttx.app/) or another equivalent tool.\n- The response is sent to the right topic, and `Mqtt` is listening to that topic.\n- The instance of `Mqtt` is up and running on a separate coroutine using `start()` before calling `request()`. This is required for `request()` to retrieve the response over mqtt.\n',
    'author': 'snorkman88',
    'author_email': 'milton@ecog.io>, tropxy <andre@ecog.io>, mdwcrft, HugoJP1, proelke <proelke@gmail.com>, ikaratass <ibrahim@ecog.io>, RoastVeg <louis@ecog.io>, johny,  santiagosalamandri, OSkrk <oscar@ecog.io>, danielgordon, Auke Oosterhoff <auke@ecog.io',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/SwitchEV/tree/main/legacy',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
