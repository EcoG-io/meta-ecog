class MqttApiValidationError(Exception):
    pass
