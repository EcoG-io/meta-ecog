import json
import logging
import os
from typing import Any, Dict

import jsonschema

from mqtt_api.exceptions import MqttApiValidationError

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger("mqtt_api")

schemas_cache: Dict[str, Any] = {}


def snake_to_pascal_case(name: str) -> str:
    """Convert a string from snake_case to PascalCase."""
    res = name.replace("_", " ").title().replace(" ", "")
    return res


def validate_message(message: dict) -> None:
    """Validate a message against its respective schema."""
    try:
        schema_file_name = snake_to_pascal_case(message["name"] + "_" + message["type"])
    except KeyError as e:
        raise MqttApiValidationError(f"Error accessing the key {e}")
    real_dir, _ = os.path.split(os.path.realpath(__file__))
    relative_path = f"schemas/{schema_file_name}.json"
    path = os.path.join(real_dir, relative_path)
    if schema_file_name not in schemas_cache.keys():
        try:
            with open(path, "r", encoding="utf-8") as f:
                schema_data = f.read()
            schema = json.loads(schema_data)
            validator_class = jsonschema.validators.validator_for(schema)
            validator = validator_class(schema)
            schemas_cache[schema_file_name] = validator
        except FileNotFoundError as e:
            raise MqttApiValidationError(f"Cannot find a JSON schema named {e}")
        except json.JSONDecodeError as e:
            raise MqttApiValidationError(
                f"Error decoding JSON schema {schema_file_name}: {e}"
            )
    else:
        validator = schemas_cache[schema_file_name]
    try:
        validator.validate(message)
    except jsonschema.ValidationError as e:
        raise MqttApiValidationError(
            f"The message {message} did not pass validation against the schema.{e}"
        )
