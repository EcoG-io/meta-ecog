from enum import Enum


class MqttCredentials(str, Enum):
    URL = "broker.hivemq.com"
    USERNAME = None
    PASS = None


class Topics(str, Enum):
    SLAC_OCPP = "slac/ocpp"
    OCPP_SLAC = "ocpp/slac"
    ISO15118_OCPP = "iso15118/ocpp"
    OCPP_ISO15118 = "ocpp/iso15118"
    JOSEV_CS = "josev/cs"
    CS_JOSEV = "cs/josev"
    ISO15118_SLAC = "iso15118/slac"
    SLAC_ISO15118 = "slac/iso15118"
    GRIDCODE_ISO15118 = "gridcode/iso15118"
    ISO15118_GRIDCODE = "iso15118/gridcode"
    GRIDCODE_OCPP = "gridcode/ocpp"
    OCPP_GRIDCODE = "ocpp/gridcode"
    OCPP_SMART_CHARGING = "ocpp/smart_charging"
    SMART_CHARGING_OCPP = "smart_charging/ocpp"
    ISO15118_SMART_CHARGING = "iso15118/smart_charging"
    SMART_CHARGING_ISO15118 = "smart_charging/iso15118"


class MessageName(str, Enum):
    AUTHORIZATION = "authorization"
    BOOT_STATUS = "boot_status"
    CABLE_CHECK = "cable_check"
    CABLE_INFO = "cable_info"
    CERTIFICATE_INSTALLATION_STATUS = "certificate_installation_status"
    CHANGE_AVAILABILITY = "change_availability"
    CHARGING_CONTACTOR = "charging_contactor"
    CHARGING_CONTACTOR_STATUS = "charging_contactor_status"
    CHARGING_SETPOINT = "charging_setpoint"
    CLEAR_CHARGING_PROFILE = "clear_charging_profile"
    CLOCK_SYNC = "clock_sync"
    CONNECTOR_AND_CHARGING = "connector_and_charging"
    COST_UPDATED = "cost_updated"
    CP_PWM = "cp_pwm"
    CP_STATUS = "cp_status"
    CS_CONTACTOR_STATUS = "cs_contactor_status"
    CS_CONNECTOR = "cs_connector"
    CS_PARAMETERS = "cs_parameters"
    CS_STATUS_AND_LIMITS = "cs_status_and_limits"
    DATA_TRANSFER = "data_transfer"
    SLAC_DATA_LINK = "slac_data_link"
    DEVICE_MODEL = "device_model"
    DEVICE_MODEL_RESET = "device_model_reset"
    DEVICE_MODEL_UPDATE = "device_model_update"
    DISPLAY_AND_PERSONAL_MSG = "display_and_personal_msg"
    DISPLAY_PARAMS = "display_params"
    EV_RATED_LIMITS = "ev_rated_limits"
    GENERATE_CSR = "generate_csr"
    GRID_CODE_SETTINGS = "grid_code_settings"
    REMOTE_GRID_CODE_OPERATION = "remote_grid_code_operation"
    HARDWARE_FAULT = "hardware_fault"
    HLC_CHARGING = "hlc_charging"
    ISO15118_AUTHORIZATION = "iso15118_authorization"
    ISO15118_CHARGE_LIMIT = "iso15118_charge_limit"
    ISO15118_GET_EV_CERTIFICATE = "iso15118_get_ev_certificate"
    ISO15118_MESSAGE = "iso15118_message"
    ISO15118_CHARGING_LOOP_POWER_LIMITS = "iso15118_charging_loop_power_limits"
    ISO15118_STATE_INFO = "iso15118_state_info"
    NOTIFY_EVENT = "notify_event"
    METER_VALUES = "meter_values"
    OCPP_MESSAGE = "ocpp_message"
    PARKING_BAY = "parking_bay"
    POWER_ELECTRONICS_SETPOINT = "power_electronics_setpoint"
    PRIVATE_KEY_PATH = "private_key_path"
    PROCESS_AUTHORIZED_TOKEN = "process_authorized_token"  # noqa: S105
    RESET = "reset"
    RESET_OCPP_ROUTER_STATE = (
        "reset_ocpp_router_state"  # Not in gitbook, used for internal testing
    )
    SDP = "sdp"
    SET_CHARGING_PROFILE = "set_charging_profile"
    SET_OCPP_NETWORK_CONNECTION = "set_ocpp_network_connection"
    SLAC_STATUS = "slac_status"
    SLAC_LINK_STATUS = "slac_link_status"
    SLAC_NETWORK_INFO = "slac_network_info"
    STOP_CHARGING = "stop_charging"
    TRANSACTION_STATUS = "transaction_status"
    SET_VARIABLE_VALIDATE = "set_variable_validate"
    WEBSOCKET_STATUS = "websocket_status"
    SERVICE_STATUS = "service_status"
    UPDATE_FIRMWARE = "update_firmware"
    FIRMWARE_STATUS = "firmware_status"
    UPLOAD_LOGS = "upload_logs"
    LOGS_STATUS = "logs_status"


class MessageStatus(str, Enum):
    ACCEPTED = "accepted"
    REJECTED = "rejected"


class BootStatus(str, Enum):
    ACCEPTED = "accepted"
    PENDING = "pending"
    REJECTED = "rejected"


class ActionType(str, Enum):
    REQUEST = "request"
    RESPONSE = "response"
    UPDATE = "update"


class AuthorizationTokenType(str, Enum):
    CENTRAL = "central"
    E_MAID = "e_maid"
    ISO14443 = "ISO14443"
    ISO15693 = "ISO15693"
    KEY_CODE = "key_code"
    LOCAL = "local"
    MAC_ADDRESS = "mac_address"
    NO_AUTHORIZATION = "no_authorization"


class AuthorizationStatus(str, Enum):
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    DEAUTHORIZED = "deauthorized"


class AuthorizeCertificateStatus(str, Enum):
    OK = "OK"
    EXPIRED = "CertificateExpired"
    EXPIRES_SOON = "CertificateExpiresSoon"
    NOT_ALLOWED_AT_THIS_EVSE = "CertificateNotAllowedAtThisEVSE"
    NOT_YET_VALID = "CertificateNotYetValid"
    REVOKED = "CertificateRevoked"
    VALIDATION_ERROR = "CertificateValidationError"
    CONTRACT_CANCELLED = "ContractCancelled"
    EMSP_UNKNOWN = "EMSPUnknown"
    GENERAL_PNC_AUTH_ERROR = "GeneralPnCAuthorizationError"


class SlacStatus(str, Enum):
    MATCHING = "matching"
    FAILED = "failed"
    MATCHED = "matched"
    UNMATCHED = "unmatched"
    BASIC_CHARGING = "basic_charging"


class EVSEIsolationStatus(str, Enum):
    VALID = "valid"
    INVALID = "invalid"
    WARNING = "warning"
    FAULT = "fault"
    NO_IMD = "no_imd"


class OperationalStatus(str, Enum):
    OPERATIVE = "operative"
    INOPERATIVE = "inoperative"


class OcppMessageName(str, Enum):
    GET_VARIABLES = "GetVariables"
    GET_INSTALLED_CERTIFICATE_IDS = "GetInstalledCertificateIds"
    SET_VARIABLES = "SetVariables"
    INSTALL_CERTIFICATE = "InstallCertificate"
    DELETE_CERTIFICATE = "DeleteCertificate"
    SET_NETWORK_PROFILE = "SetNetworkProfile"
    CERTIFICATE_SIGNED = "CertificateSigned"
    SIGN_CERTIFICATE = "SignCertificate"
    NOTIFY_EV_CHARGING_NEEDS = "NotifyEVChargingNeeds"
    UPDATE_DYNAMIC_SCHEDULE = "UpdateDynamicSchedule"
    SET_CHARGING_PROFILE = "SetChargingProfile"


class OcppVersion(str, Enum):
    OCPP16 = "ocpp1.6"
    OCPP201 = "ocpp2.0.1"
    OCPP21 = "ocpp2.1"


class OcppMessageType(str, Enum):
    CALL = "Call"
    CALLRESULT = "CallResult"
    CALLERROR = "CallError"


class ParkingBayStatus(str, Enum):
    EV_DEPARTED = "ev_departed"
    EV_DETECTED = "ev_detected"


class KeystoreCertificateType(str, Enum):
    CHARGING_STATION_CERTIFICATE = "charging_station_certificate"
    V2G_CERTIFICATE = "v2g_certificate"


class CertificateInstallationState(str, Enum):
    INSTALLED = "installed"
    DELETED = "deleted"
    FAILED_INSTALLATION = "failed_installation"


class ConnectorStatus(str, Enum):
    AVAILABLE = "available"
    OCCUPIED = "occupied"
    UNAVAILABLE = "unavailable"
    RESERVED = "reserved"
    FAULTED = "faulted"


class ConnectorCsSideStatus(str, Enum):
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"
    UNKNOWN = "unknown"


class CsConnectorAction(str, Enum):
    LOCK = "lock"
    UNLOCK = "unlock"
    STATUS = "status"


class CsConnectorStatus(str, Enum):
    ERROR = "error"
    LOCKED = "locked"
    UNLOCKED = "unlocked"
    UNKNOWN = "unknown"


class ChargingStatus(str, Enum):
    EV_CONNECTED = "ev_connected"
    SUSPENDED_EV = "suspended_ev"
    SUSPENDED_EVSE = "suspended_evse"
    CHARGING = "charging"
    IDLE = "idle"


class CpPwmCommandStatus(str, Enum):
    VALID = "valid"
    INVALID = "invalid"
    ERROR = "error"


class CsContactorStatus(str, Enum):
    ERROR = "error"
    OPENED = "opened"
    CLOSED = "closed"


class CsAuthorizationStatus(str, Enum):
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    DEAUTHORIZED = "deauthorized"


class Iso15118AuthorizationStatus(str, Enum):
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    ONGOING = "ongoing"


class CsAuthorizationTokenType(str, Enum):
    KEY_CODE = "key_code"
    LOCAL = "local"
    NO_AUTHORIZATION = "no_authorization"
    ISO14443 = "ISO14443"
    ISO15693 = "ISO15693"


class Iso15118AuthorizationTokenType(str, Enum):
    MAC_ADDRESS = "mac_address"
    E_MAID = "e_maid"


class Iso15118CertificateAction(str, Enum):
    INSTALL = "install"
    UPDATE = "update"


class Iso15118SchemaVersion(str, Enum):
    V2_MSG_DEF = "urn:iso:15118:2:2013:MsgDef"
    V20_COMMON_MESSAGES = "urn:iso:std:iso:15118:-20:CommonMessages"
    DIN_SPEC_70121 = "urn:din:70121:2012:MsgDef"
    ISO15118_2_APP_PROTOCOL = "urn:iso:15118:2:2010:AppProtocol"
    ISO15118_20_AC = "urn:iso:std:iso:15118:-20:AC"
    ISO15118_20_DC = "urn:iso:std:iso:15118:-20:DC"
    ISO15118_20_ACDP = "urn:iso:std:iso:15118:-20:ACDP"
    ISO15118_20_WPT = "urn:iso:std:iso:15118:-20:WPT"


class Iso15118CertificateStatus(str, Enum):
    ACCEPTED = "accepted"
    FAILED = "failed"


class Iso15118SessionStatus(str, Enum):
    IDLE = "Idle"
    SESSION_SETUP = "SessionSetup"
    SERVICE_DISCOVERY = "ServiceDiscovery"
    SERVICE_DETAIL = "ServiceDetail"
    CERTIFICATE_INSTALLATION = "CertificateInstallation"
    SUPPORTED_APP_PROTOCOL = "SupportedAppProtocol"
    SERVICE_SELECTION = "ServiceSelection"
    AUTHORIZATION_SETUP = "AuthorizationSetup"
    AUTHORIZATION = "Authorization"
    CHARGE_PARAMETER_DISCOVERY = "ChargeParameterDiscovery"
    SCHEDULE_EXCHANGE = "ScheduleExchange"
    CABLE_CHECK = "CableCheck"
    PRE_CHARGE = "PreCharge"
    POWER_DELIVERY = "PowerDelivery"
    CHARGING_LOOP = "ChargingLoop"
    METERING_RECEIPT = "MeteringReceipt"
    WELDING_DETECTION = "WeldingDetection"
    SESSION_STOP = "SessionStop"


class Iso15118MessageType(str, Enum):
    REQUEST = "Request"
    RESPONSE = "Response"
    ERROR = "Error"


class FaultNameType(str, Enum):
    EMERGENCY_STOP = "emergency_stop"
    ENERGY_LIMIT_REACHED = "energy_limit_reached"
    GROUND_FAULT = "ground_fault"
    OTHER = "other"
    OVERCURRENT_FAULT = "overcurrent_fault"
    POWER_LOSS = "power_loss"
    POWER_QUALITY = "power_quality"
    REBOOT = "reboot"


class CpStates(str, Enum):
    A0 = "A0"
    A1 = "A1"
    A2 = "A2"
    B1 = "B1"
    B2 = "B2"
    C1 = "C1"
    C2 = "C2"
    D1 = "D1"
    D2 = "D2"
    E = "E"
    F = "F"


class DeviceModelMutabilityType(str, Enum):
    READ_ONLY = "ReadOnly"
    WRITE_ONLY = "WriteOnly"
    READ_WRITE = "ReadWrite"


class DataType(str, Enum):
    STRING = "string"
    DECIMAL = "decimal"
    INTEGER = "integer"
    DATETIME = "dateTime"
    BOOLEAN = "boolean"
    OPTION_LIST = "OptionList"
    SEQUENCE_LIST = "SequenceList"
    MEMBER_LIST = "MemberList"


class DeviceModelConnectorType(str, Enum):
    CCCS1 = "cCCS1"
    CCCS2 = "cCCS2"
    CG105 = "cG105"
    CTESLA = "cTesla"
    CTYPE1 = "cType1"
    CTYPE2 = "cType2"
    S3091P16A = "s309-1P-16A"
    S3091P32A = "s309-1P-32A"
    S3093P16A = "s309-3P-16A"
    S3093P32A = "s309-3P-32A"
    SBS1361 = "sBS1361"
    SCEE77 = "sCEE-7-7"
    STYPE2 = "sType2"
    STYPE3 = "sType3"
    OTHER1PHMAX16A = "Other1PhMax16A"
    OTHER1PHOVER16A = "Other1PhOver16A"
    OTHER3PH = "Other3Ph"
    PAN = "Pan"
    WINDUCTIVE = "wInductive"
    WRESONANT = "wResonant"
    UNDETERMINED = "Undetermined"
    UNKNOWN = "Unknown"


class Measurandtype(str, Enum):
    CURRENT_EXPORT = "Current.Export"
    CURRENT_IMPORT = "Current.Import"
    CURRENT_OFFERED = "Current.Offered"
    ENERGY_ACTIVE_EXPORT_REGISTER = "Energy.Active.Export.Register"
    ENERGY_ACTIVE_IMPORT_REGISTER = "Energy.Active.Import.Register"
    ENERGY_REACTIVE_EXPORT_REGISTER = "Energy.Reactive.Export.Register"
    ENERGY_REACTIVE_IMPORT_REGISTER = "Energy.Reactive.Import.Register"
    ENERGY_ACTIVE_EXPORT_INTERVAL = "Energy.Active.Export.Interval"
    ENERGY_ACTIVE_IMPORT_INTERVAL = "Energy.Active.Import.Interval"
    ENERGY_ACTIVE_NET = "Energy.Active.Net"
    ENERGY_REACTIVE_EXPORT_INTERVAL = "Energy.Reactive.Export.Interval"
    ENERGY_REACTIVE_IMPORT_INTERVAL = "Energy.Reactive.Import.Interval"
    ENERGY_REACTIVE_NET = "Energy.Reactive.Net"
    ENERGY_APPARENT_NET = "Energy.Apparent.Net"
    ENERGY_APPARENT_IMPORT = "Energy.Apparent.Import"
    ENERGY_APPARENT_EXPORT = "Energy.Apparent.Export"
    FREQUENCY = "Frequency"
    POWER_ACTIVE_EXPORT = "Power.Active.Export"
    POWER_ACTIVE_IMPORT = "Power.Active.Import"
    POWER_FACTOR = "Power.Factor"
    POWER_OFFERED = "Power.Offered"
    POWER_REACTIVE_EXPORT = "Power.Reactive.Export"
    POWER_REACTIVE_IMPORT = "Power.Reactive.Import"
    SOC = "SoC"
    VOLTAGE = "Voltage"


class EVSEStatusCode(str, Enum):
    EVSE_NOT_READY = "evse_not_ready"
    EVSE_READY = "evse_ready"
    EVSE_SHUTDOWN = "evse_shutdown"
    # XSD typo in "Interrupt"
    EVSE_UTILITY_INTERUPT_EVENT = "evse_utility_interrupt_event"
    EVSE_ISOLATION_MONITORING_ACTIVE = "evse_isolation_monitoring_active"
    EVSE_EMERGENCY_SHUTDOWN = "evse_emergency_shutdown"
    EVSE_MALFUNCTION = "evse_malfunction"


class EnergyTransferModeEnum(str, Enum):
    """See sections 8.5.2.4 and 8.4.3.8.2 in ISO 15118-2."""

    AC_SINGLE_PHASE_CORE = "AC_single_phase_core"
    AC_THREE_PHASE_CORE = "AC_three_phase_core"
    DC_CORE = "DC_core"
    DC_EXTENDED = "DC_extended"
    DC_COMBO_CORE = "DC_combo_core"
    DC_UNIQUE = "DC_unique"


class ControlMode(str, Enum):
    """See e.g. Table 205 in section 8.4.3.2.2 of ISO 15118-20."""

    SCHEDULED = "scheduled"
    DYNAMIC = "dynamic"


class BPTChannel(str, Enum):
    """See e.g. Table 206 in section 8.4.3.2.2.1 of ISO 15118-20."""

    UNIFIED = "unified"
    SEPARATED = "separated"


class GeneratorMode(str, Enum):
    """See e.g. Table 206 in section 8.4.3.2.2.1 of ISO 15118-20."""

    GRID_FOLLOWING = "grid_following"
    GRID_FORMING = "grid_forming"


class GridCodeIslandingDetectionMode(str, Enum):
    """See e.g. Table 206 in section 8.4.3.2.2.1 of ISO 15118-20."""

    ACTIVE = "active"
    PASSIVE = "passive"


class HashAlgorithm(str, Enum):
    """Used algorithm for the hashes provided.

    See OCSPRequestDataType in OCPP 2.0.1 specification part 2.
    Messages, Datatypes & Enumerations
    2.36. OCSPRequestDataType
    """

    SHA256 = "SHA256"
    SHA384 = "SHA384"
    SHA512 = "SHA512"


class WebsocketStatus(str, Enum):
    CONNECTING = "connecting"
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"


class ServiceName(str, Enum):
    SLAC = "slac"
    ISO15118 = "iso15118"
    OCPP = "ocpp"
    GRIDCODE = "gridcode"


class ServiceStatus(str, Enum):
    READY = "ready"
    STARTING = "starting"
    STOPPING = "stopping"
    ERROR = "error"
    BUSY = "busy"


class LogType(str, Enum):
    DIAGNOSTICS_LOG = "diagnostics_log"
    SECURITY_LOG = "security_log"


class UploadLogsStatus(str, Enum):
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    ACCEPTED_CANCELED = "accepted_canceled"


class UpdateFirmwareStatus(str, Enum):
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    ACCEPTED_CANCELED = "accepted_canceled"
    INVALID_CERTIFICATE = "invalid_certificate"
    REVOKED_CERTIFICATE = "revoked_certificate"


class FirmwareStatus(str, Enum):
    DOWNLOADING = "downloading"
    DOWNLOADED = "downloaded"
    DOWNLOAD_FAILED = "download_failed"
    DOWNLOAD_SCHEDULED = "download_scheduled"
    DOWNLOAD_PAUSED = "download_paused"
    IDLE = "idle"
    INSTALLING = "installing"
    INSTALLED = "installed"
    INSTALLATION_FAILED = "installation_failed"
    INSTALL_REBOOTING = "install_rebooting"
    INSTALL_SCHEDULED = "install_scheduled"
    INSTALL_VERIFICATION_FAILED = "install_verification_failed"
    INVALID_SIGNATURE = "invalid_signature"
    SIGNATURE_VERIFIED = "signature_verified"


class LogsStatus(str, Enum):
    ACCEPTED_CANCELED = "accepted_canceled"
    BAD_MESSAGE = "bad_message"
    IDLE = "idle"
    NOT_SUPPORTED_OPERATION = "not_supported_operation"
    PERMISSION_DENIED = "permission_denied"
    UPLOAD_FAILURE = "upload_failure"
    UPLOADED = "uploaded"
    UPLOADING = "uploading"


class DataLinkStatus(str, Enum):
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    ONGOING = "ongoing"


class DataLinkAction(str, Enum):
    PAUSE = "pause"
    TERMINATE = "terminate"
    RESUME = "resume"


class LinkStatus(str, Enum):
    CONNECTED = "connected"
    UNKNOWN = "unknown"


class AccessNetwork(str, Enum):
    IN_HOME = "InHome"
    ACCESS = "Access"
    UNKNOWN = "Unknown"


class StationRole(str, Enum):
    STA = "STA"
    PROXY_COORDINATOR = "ProxyCoordinator"
    CCO = "CCo"
    UNKNOWN = "Unknown"


class GridCodeSetttingStatus(str, Enum):
    ACCEPTED = "accepted"
    REJECTED = "rejected"


class GridCode(str, Enum):
    G98 = "G98"
    G99 = "G99"
    G98_99 = "G98_G99"
    VDE_AR_N_4105 = "VDE_AR_N_4105"
    EN_50549_1 = "EN_50549_1"


class ReactivePowerFunction(str, Enum):
    CONSTANT_REACTIVE_POWER = "ConstantReactivePower"
    CONSTANT_POWER_FACTOR = "ConstantPowerFactor"
    POWER_FACTOR_FN_OF_ACTIVE_POWER = "PowerFactor(ActivePower)"
    VOLT_VAR = "Volt-var"
    WATT_VAR = "Watt-var"


class ActivePowerFunction(str, Enum):
    CONSTANT_ACTIVE_POWER = "ConstantActivePower"
    LIMIT_ACTIVE_POWER = "LimitActivePower"
    ACTIVE_POWER_FN_OF_FREQ = "ActivePower(Freq)"
    VOLT_WATT = "Volt-Watt"


class RemoteGridCodeOperation(str, Enum):
    REMOTE_OFF = "RemoteOff"
    REMOTE_ACTIVE_POWER = "RemoteActivePower"
    REMOTE_REACTIVE_POWER = "RemoteReactivePower"


class RemoteGridCodeStatus(str, Enum):
    ACCEPTED = "accepted"
    REJECTED = "rejected"


class ChargingRateUnit(str, Enum):
    W = "W"
    A = "A"


class ChargingProfilePurpose(str, Enum):
    CHARGING_STATION_EXTERNAL_CONSTRAINTS = "ChargingStationExternalConstraints"
    CHARGING_STATION_MAX_PROFILE = "ChargingStationMaxProfile"
    TX_DEFAULT_PROFILE = "TxDefaultProfile"
    TX_PROFILE = "TxProfile"


class SecurityType(str, Enum):
    TLS = "tls"
    NO_TLS = "no_tls"


class ChargingProfileKind(str, Enum):
    ABSOLUTE = "Absolute"
    RECURRING = "Recurring"
    RELATIVE = "Relative"


class RecurrencyKind(str, Enum):
    DAILY = "Daily"
    WEEKLY = "Weekly"


class CableCheckAction(str, Enum):
    START = "start"
    STATUS = "status"


class CableCheckStatus(str, Enum):
    ONGOING = "ongoing"
    FINISHED = "finished"


class IsolationLevel(str, Enum):
    INVALID = "invalid"
    VALID = "valid"
    WARNING = "warning"
    FAULT = "fault"
    NO_IMD = "no_imd"


class DataTransferStatus(str, Enum):
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    UNKNOWN_MESSAGE_ID = "unknown_message_id"
    UNKNOWN_VENDOR_ID = "unknown_vendor_id"


class SetPointRequestStatus(str, Enum):
    ACCEPTED = "accepted"
    REJECTED = "rejected"


class ClearChargingProfileStatus(str, Enum):
    ACCEPTED = "accepted"
    UNKNOWN = "unknown"


class DisplayMsgTriggerReason(str, Enum):
    DISPLAY_MESSAGE = "display_message"
    AUTHORIZED = "authorized"
    UPDATED = "updated"
    ENDED = "ended"


class Priority(str, Enum):
    ALWAYS_FRONT = "always_front"
    IN_FRONT = "in_front"
    NORMAL_CYCLE = "normal_cycle"


class AuthorizedTokenStatus(str, Enum):
    ACCEPTED = "accepted"
    DISCARDED = "discarded"


class PrivateKeyAlgorithm(str, Enum):
    ECDSA_SHA256 = "ECDSA_SHA256"
    RSA_SHA256 = "RSA_SHA256"
    RSA_SHA384 = "RSA_SHA384"


class PrivateKeyPathStatus(str, Enum):
    ACCEPTED = "accepted"
    FAILED_NOT_FOUND = "failed_not_found"


class MessageState(str, Enum):
    CHARGING = "charging"
    FAULTED = "faulted"
    IDLE = "idle"
    UNAVAILABLE = "unavailable"


class TransactionStatus(str, Enum):
    STARTED = "started"
    IN_PROGRESS = "in_progress"
    ENDED = "ended"


class VariableAttribute(str, Enum):
    ACTUAL = "Actual"
    TARGET = "Target"
    MINSET = "MinSet"
    MAXSET = "MaxSet"
