import asyncio
import inspect
import logging
import time
import uuid
from dataclasses import asdict
from typing import Any, Awaitable, Callable, Dict, List, Optional

from asyncio_mqtt import Client, MqttError
from paho.mqtt.client import MQTTMessage

from mqtt_api.messages import Request, Response, Update, unpack
from mqtt_api.routing import create_route_map
from mqtt_api.utils import camel_to_snake_case, remove_nones
from mqtt_api.v1 import response
from mqtt_api.v1.enums import ActionType, MessageName
from mqtt_api.validator import validate_message

logger = logging.getLogger("mqtt_api")

AsyncMessageConsumer = Callable[[str, str], Awaitable[None]]


def response_topic(topic: str) -> str:
    """Reverse the given topic to create a response topic."""
    components = topic.split("/")
    return f"{components[1]}/{components[0]}"


class Mqtt:
    def __init__(
        self,
        mqtt_client: Callable[[], Client],
        topics: List[str],
        response_timeout: int = 30,
    ) -> None:
        """Object initialization.

        Args:
            mqtt_client: Mqtt client
            response_timeout: Interval to wait for response
        """
        self._mqtt_client = mqtt_client
        self._topics = topics
        self._response_timeout = response_timeout
        self._response_messages: Dict[str, Response] = {}
        self._receive_lock = asyncio.Lock()
        self._response_event = asyncio.Event()
        self._response = response
        self._unique_id_generator = uuid.uuid4
        self._is_ready = False
        self._client: Optional[Client] = None
        self.route_map = create_route_map(self)

        self._after_incoming: Optional[AsyncMessageConsumer] = None
        self._before_outgoing: Optional[AsyncMessageConsumer] = None

    @property
    def after_incoming(self) -> Optional[AsyncMessageConsumer]:
        return self._after_incoming

    @after_incoming.setter
    def after_incoming(self, callback: AsyncMessageConsumer) -> None:
        self._after_incoming = callback

    @property
    def before_outgoing(self) -> Optional[AsyncMessageConsumer]:
        return self._before_outgoing

    @before_outgoing.setter
    def before_outgoing(self, callback: AsyncMessageConsumer) -> None:
        self._before_outgoing = callback

    @property
    def is_ready(self) -> bool:
        return self._is_ready

    async def on_after_incoming(self, topic: str, message: str) -> None:
        """Invoke after_incoming hook if not None.

        Args:
            topic: to pass to hook
            message: to pass to hook
        """
        if self.after_incoming:
            await self.after_incoming(topic, message)

    async def on_before_outgoing(self, topic: str, message: str) -> None:
        """Invoke before_outgoing hook if not None.

        Args:
            topic: to pass to hook
            message: to pass to hook
        """
        if self.before_outgoing:
            await self.before_outgoing(topic, message)

    async def route_message(self, raw_message: MQTTMessage) -> None:
        """
        Route a message received from an MQTT topic.

        If the message is of type Request or Update the corresponding hooks
        are executed.
        If the message is of type Response the message is passed
        to the request() function via the response_queue.
        """
        topic, message = unpack(raw_message)

        if topic is None or message is None:
            logger.info(f"Could not extract topic or message from {raw_message=}")
            return

        # Log sending message on debug level to improve performance
        logger.debug(f"From {topic=} received {message=}")

        if isinstance(message, Request):
            await self._handle_request(topic, message)

        elif isinstance(message, Update):
            await self._handle_update(message)

        elif isinstance(message, Response):
            async with self._receive_lock:
                self._response_messages[message.id] = message
                self._response_event.set()

    async def start(self) -> None:
        """Start listening for messages."""
        mqtt_reconnect_interval = 5  # In seconds
        logger.info("Starting MQTT client.")
        logger.info(f"MQTT reconnection retry interval is {mqtt_reconnect_interval}.")
        while True:
            try:
                async with self._mqtt_client() as client:
                    async with client.unfiltered_messages() as messages:
                        await client.subscribe([(topic, 1) for topic in self._topics])
                        self._is_ready = True
                        self._client = client
                        try:
                            async for message in messages:
                                await self.on_after_incoming(
                                    message._topic.decode(),
                                    str(message.payload.decode()),
                                )
                                asyncio.create_task(self.route_message(message))
                        except asyncio.CancelledError as e:
                            await client.unsubscribe(self._topics)
                            raise e
                        except NotImplementedError as e:
                            logger.exception(f"{e}")
            except MqttError as error:
                logger.error(
                    f"Error {error}. Reconnecting in {mqtt_reconnect_interval} seconds."
                )
                await asyncio.sleep(mqtt_reconnect_interval)

    async def _handle_request(self, topic: str, msg: Request) -> None:
        """
        Handle incoming requests.

        Execute all hooks installed for a message based on the Name of the message.
        First the '_on_action' hook is executed and its response is returned to
        the client. If there is no '_on_action' hook for Action in the message
        NotImplementedError is raised.
        Next the '_after_action' hook is executed.
        """
        try:
            handlers = self.route_map[msg.name]
        except KeyError:
            logger.debug(f"No handler for {msg.name} registered. Returning.")
            return

        validate_message(msg.to_dict())

        try:
            handler = handlers["_on_action"]
        except KeyError:
            raise NotImplementedError(f"No handler for {msg.name} " "registered.")
        try:
            action_type_expected = handler._action_type
            if (
                action_type_expected is not None
                and action_type_expected != ActionType.REQUEST
            ):
                return
        except AttributeError:
            pass
        try:
            response = handler(**msg.data)
            if inspect.isawaitable(response):
                response = await response
        except Exception:
            logger.exception("Error while handling request '%s'", msg)
            return

        temp_response_payload = asdict(response)
        response_payload = remove_nones(temp_response_payload)

        response_message = msg.create_response(response_payload)

        validate_message(response_message.to_dict())

        publish_topic = response_topic(topic)
        await self._publish(response_message.to_json(), publish_topic)

        try:
            handler = handlers["_after_action"]
            # Create task to avoid blocking when making a call inside the
            # after handler
            response = handler(msg.data, response_payload)
            if inspect.isawaitable(response):
                await response
        except KeyError:
            # '_on_after' hooks are not required. Therefore ignore exception
            # when no '_on_after' hook is installed.
            pass

    async def _handle_update(self, msg: Update) -> None:
        """
        Handle incoming updates.

        Execute all hooks installed for a message based on the Name of the message.
        First the '_on_action' hook is executed and its response is returned to
        the client. If there is no '_on_action' hook for Action in the message
        NotImplementedError is raised.
        Next the '_after_action' hook is executed.
        """
        try:
            handlers = self.route_map[msg.name]
        except KeyError:
            logger.debug(f"No handler for {msg.name} registered. Returning.")
            return

        validate_message(msg.to_dict())

        try:
            handler = handlers["_on_action"]
        except KeyError:
            raise NotImplementedError(f"No handler for {msg.name} registered.")

        try:
            action_type_expected = handler._action_type
            if (
                action_type_expected is not None
                and action_type_expected != ActionType.UPDATE
            ):
                return
        except AttributeError:
            pass
        try:
            response = handler(**msg.data)
            if inspect.isawaitable(response):
                await response

        except Exception:
            logger.exception("Error while handling request '%s'", msg)

        try:
            handler = handlers["_after_action"]
            # Create task to avoid blocking when making a call inside the
            # after handler
            response = handler(**msg.data)
            if inspect.isawaitable(response):
                await response
        except KeyError:
            # '_on_after' hooks are not required. Therefore ignore exception
            # when no '_on_after' hook is installed.
            pass

    async def request(self, topic: str, payload: Any) -> Any:
        """Construct a Request message."""
        message_name = camel_to_snake_case(payload.__class__.__name__[:-7]).upper()

        request = Request(
            id=str(self._unique_id_generator()),
            name=MessageName[message_name],
            data=remove_nones(asdict(payload)),
        )

        validate_message(request.to_dict())

        await self._publish(request.to_json(), topic)

        try:
            response = await self._get_specific_response(
                request.id, self._response_timeout
            )
        except asyncio.TimeoutError as timeout_error:
            raise asyncio.TimeoutError(
                f"Waited {self._response_timeout}s for response on "
                f"{request.to_json()}."
            ) from timeout_error

        response.name = request.name
        validate_message(response.to_dict())

        cls = getattr(self._response, payload.__class__.__name__)
        return cls(**response.data)

    async def update(self, topic: str, payload: Any) -> None:
        """Construct an Update message."""
        message_name = camel_to_snake_case(payload.__class__.__name__[:-7]).upper()

        update = Update(
            id=str(self._unique_id_generator()),
            name=MessageName[message_name],
            data=remove_nones(asdict(payload)),
        )

        validate_message(update.to_dict())

        await self._publish(update.to_json(), topic)

    async def _publish(self, payload: str, publish_topic: str, qos: int = 1) -> None:
        """Wrap function around the MQTT client publish."""
        if self._client is None:
            logger.error("MQTT is not ready")
            return
        await self.on_before_outgoing(publish_topic, payload)
        if '"name":"iso15118_message"' not in payload:
            # TODO: Refactor to check this on the message_name object DevOps#2636
            logger.debug("Sending %s to topic %s", payload, publish_topic)

        await self._client.publish(topic=publish_topic, payload=payload, qos=qos)

    async def _read_message_with_id(self, id: str) -> Optional[Response]:
        try:
            message_received = False
            while not message_received:
                await self._response_event.wait()
                async with self._receive_lock:
                    try:
                        message = self._response_messages.pop(id)
                        message_received = True
                        return message
                    except KeyError:
                        self._response_event.clear()

        except Exception:  # noqa
            pass
        return None

    async def _get_specific_response(self, id: str, timeout: float) -> Response:
        """Return response with given unique ID or raise an asyncio.TimeoutError."""
        wait_until = time.time() + timeout
        try:
            # Wait for response of the Call message.
            response = await asyncio.wait_for(self._read_message_with_id(id), timeout)
        except asyncio.TimeoutError:
            raise

        if response and response.id == id:
            return response

        logger.error("Ignoring response with unknown unique id: %s", response)
        timeout_left = wait_until - time.time()

        if timeout_left < 0:
            raise asyncio.TimeoutError

        return await self._get_specific_response(id, timeout_left)
